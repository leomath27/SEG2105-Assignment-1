package Question2;
import java.util.LinkedList;
import java.util.Random;
public class AddingLinkedList{
    public static void main(String[] args) {
        int X = 81920000;
        LinkedList<Byte> linkedList = new LinkedList<>();
        System.out.println("\nLinkedList:");
        populateLinkedList(linkedList, X);
        measureASumTimell(linkedList, X);      }    
    private static void populateLinkedList(LinkedList<Byte> linkedList, int size) {
        long startTime = System.currentTimeMillis();
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            byte value = (byte) (random.nextInt(256) - 128);
            linkedList.add(value);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("The time taken to populate the LinkedList is " + (endTime - startTime) + " milliseconds");
    }
    private static void measureASumTimell(LinkedList<Byte> LinkedList, int size) {
        long startTime = System.currentTimeMillis();
        int sum = 0;
        for (Byte value : LinkedList) {
            sum += value;
        }
        long endTime = System.currentTimeMillis();
        System.out.println("The sum was= " + sum);
        System.out.println("The time taken to measure sum of the LinkedList is " + (endTime - startTime) + " milliseconds");
    }}