package Question2;
import java.util.LinkedList;

public class LinkedListTest {
    public static void main(String[] args) {
        long startTime, endTime;
        int X = 10000; 
        LinkedList<Byte> linkedList = new LinkedList<>();
        for (int warmup = 0; warmup < 3; warmup++) {
            linkedList.clear();
            for (int i = 0; i < X; i++) {
                byte value = (byte) (Math.random() * 256 - 128);
                linkedList.add(value);
            }
        }

        do {
            try {
                linkedList.clear();
                startTime = System.currentTimeMillis();
                for (int i = 0; i < X; i++) {
                    byte value = (byte) (Math.random() * 256 - 128);
                    linkedList.add(value);
                }
                endTime = System.currentTimeMillis();

                if ((endTime - startTime) < 5000) {
                    X *= 2; 
                } else {
                    break;
                }
            } catch (OutOfMemoryError e) {
                X /= 2;
            }
        } while (true);

        System.out.println("X value for at least 5 seconds: " + X);
        System.out.println("The time taken to achieve this is: " + (endTime - startTime));
    }
}
