package Question2;
import java.util.ArrayList;
import java.util.Random;

public class FillingIn {
    public static void main(String[] args) {
        int X = 81920000;
        ArrayList<Byte> arrayList = new ArrayList<>(X);
        byte[] byteArray = new byte[X];

        System.out.println("ArrayList:");
        populateArrayList(arrayList, X);
        measureASumTimeal(arrayList, X);
        
        System.out.println("\nArray:");
        populateArray(byteArray,X);
        measureASumArray(byteArray,X); 
    }

    private static void populateArrayList(ArrayList<Byte> arrayList, int size) {
        long startTime = System.currentTimeMillis();
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            byte value = (byte) (random.nextInt(256) - 128);
            arrayList.add(value);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("The time taken to populate the ArrayList is " + (endTime - startTime) + " milliseconds");
    }
        
        
    private static void measureASumTimeal(ArrayList<Byte> ArrayList, int size) {
        long startTime = System.currentTimeMillis();
        int sum = 0;
        for (int i = 0; i < size; i++) {
            sum += ArrayList.get(i);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("The sum was= " + sum);
        System.out.println("The time taken to measure the sum of the ArrayList is " + (endTime - startTime) + " milliseconds");
    }

    private static void populateArray(byte[] array, int size) {
        long startTime = System.currentTimeMillis();
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            array[i] = (byte) (random.nextInt(256) - 128);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("The time taken to populate the Array is " + (endTime - startTime) + " milliseconds");
    }

    private static void measureASumArray(byte[] array, int size) {
        long startTime = System.currentTimeMillis();
        int sum = 0;
        for (int i = 0; i < size; i++) {
            sum += array[i];
        }
        long endTime = System.currentTimeMillis();
        System.out.println("The sum was= " + sum);
        System.out.println("The time taken to measure the Sum of Array is " + (endTime - startTime) + " milliseconds");
    }
}
