package TestingPerformance;
import design1.PointCP;
import design5.PointCP5;
import design5.PointCP2;
import design5.PointCP3;
import java.util.Random;
public class PerformanceTest {
    public static void main(String[] args) {
        int numPoints = 100000;
        long startTime, endTime;
        int numPointsCreatedDesign1 = 0;
        int numPointsCreatedDesign5 = 0;
        System.out.println("Experiment 1: Number of Points Created in 10 Seconds");
        startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < 10000) {
            new PointCP('C', Math.random() * 100, Math.random() * 100);
            numPointsCreatedDesign1++;
        }
        endTime = System.currentTimeMillis();
        System.out.println("Design 1 - Points Created: " + numPointsCreatedDesign1);
        System.out.println("Time Taken (ms): " + (endTime - startTime));

        startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < 10000) {
            new PointCP2(Math.random() * 100, Math.random() * 100);
            numPointsCreatedDesign5++;
        }
        endTime = System.currentTimeMillis();
        System.out.println("Design 5 (Design 2 subclass) - Points Created: " + numPointsCreatedDesign5);
        System.out.println("Time Taken (ms): " + (endTime - startTime));
        System.out.println("\nExperiment 2: Time Taken to Create and Call " + numPoints + " Points");
        PointCP[] pointsDesign1 = new PointCP[numPoints];
        PointCP5[] pointsDesign5 = new PointCP5[numPoints];
        for (int i = 0; i < numPoints; i++) {
            pointsDesign1[i] = new PointCP('C', Math.random() * 100, Math.random() * 100);
        }
        for (int i = 0; i < numPoints; i++) {
            pointsDesign5[i] = new PointCP2(Math.random() * 100, Math.random() * 100);
        }
        startTime = System.currentTimeMillis();
        for (int i = 0; i < numPoints; i++) {
            double x = pointsDesign1[i].getX();
            double y = pointsDesign1[i].getY();
            pointsDesign1[i].convertStorageToPolar();
        }
        endTime = System.currentTimeMillis();
        System.out.println("Design 1 - Time Taken (ms): " + (endTime - startTime));
        startTime = System.currentTimeMillis();
        for (int i = 0; i < numPoints; i++) {
            double x = pointsDesign5[i].getX();
            double y = pointsDesign5[i].getY();
            pointsDesign5[i].convertStorageToPolar();
        }
        endTime = System.currentTimeMillis();
        System.out.println("Design 5 (Design 2 subclass) - Time Taken (ms): " + (endTime - startTime));
    }
}