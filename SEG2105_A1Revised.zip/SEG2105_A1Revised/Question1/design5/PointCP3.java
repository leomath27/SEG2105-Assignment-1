package design5;

public class PointCP3 extends PointCP5 {

    public PointCP3(double x, double y) {
        super(x, y);
    }

    @Override
    public double getX() {
        return xOrRho;
    }

    @Override
    public double getY() {
        return yOrTheta;
    }

    @Override
    public double getRho() {
        return Math.sqrt(xOrRho * xOrRho + yOrTheta * yOrTheta);
    }

    @Override
    public double getTheta() {
        return Math.atan2(yOrTheta, xOrRho);
    }

    @Override
    public PointCP5 convertStorageToPolar() {
        return new PointCP2(getRho(), getTheta()); // Convert to polar
    }

    @Override
    public PointCP5 convertStorageToCartesian() {
        return this; // Already in Cartesian form
    }

    @Override
    public String toString() {
        return "Stored as Cartesian (" + getX() + "," + getY() + ")\n";
    }
}