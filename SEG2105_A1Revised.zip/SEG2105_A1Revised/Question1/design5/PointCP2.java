package design5;

public class PointCP2 extends PointCP5 {

    public PointCP2(double rho, double theta) {
        super(rho, theta);
    }

    @Override
    public double getX() {
        return xOrRho * Math.cos(yOrTheta);
    }

    @Override
    public double getY() {
        return xOrRho * Math.sin(yOrTheta);
    }

    @Override
    public double getRho() {
        return xOrRho;
    }

    @Override
    public double getTheta() {
        return yOrTheta;
    }

    @Override
    public PointCP5 convertStorageToPolar() {
        return this; // Already in polar form
    }

    @Override
    public PointCP5 convertStorageToCartesian() {
        return new PointCP3(getX(), getY()); // Convert to Cartesian
    }

    @Override
    public String toString() {
        return "Stored as Polar [" + getRho() + "," + getTheta() + "]\n";
    }
}